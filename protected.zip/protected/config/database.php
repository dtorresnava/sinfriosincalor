<?php

// This is the database connection configuration.
return array(
	
	// uncomment the following lines to use a MySQL database
	/*'connectionString' => 'sqlite:'.dirname(__FILE__).'/../data/testdrive.db',*/
	'connectionString' => 'mysql:host=localhost;dbname=u525287753_sfsc',
	'emulatePrepare' => true,
	'username' => 'root',
	'password' => 'root',
	'charset' => 'utf8',
	
);